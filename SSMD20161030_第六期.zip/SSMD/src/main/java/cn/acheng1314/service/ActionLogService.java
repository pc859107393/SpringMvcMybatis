package cn.acheng1314.service;

import cn.acheng1314.domain.UserActionLog;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * Created by 程 on 2016/10/28.
 */
public interface ActionLogService extends BaseService<UserActionLog> {
    void add(HttpServletRequest request);

    List<UserActionLog> findAll(int pageNum, int pageSize);
}
