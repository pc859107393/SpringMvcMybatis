package cn.acheng1314.mvc.api;

/**
 * Created by Administrator on 2016/9/25.
 */
public class ApiUser {
}
