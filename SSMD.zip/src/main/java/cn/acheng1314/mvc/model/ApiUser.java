package cn.acheng1314.mvc.model;

/**
 * Created by Administrator on 2016/9/25.
 */
public class ApiUser {
}
