package cn.acheng1314.service;


/**
 * Created by Administrator on 2016/9/25.
 */
public interface BaseService<T> {
    void add(T t) throws Exception;
}
