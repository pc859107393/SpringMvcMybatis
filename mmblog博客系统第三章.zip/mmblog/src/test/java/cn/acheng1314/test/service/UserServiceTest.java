package cn.acheng1314.test.service;

import cn.acheng1314.service.userService.UserService;
import cn.acheng1314.test.BaseTest;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.HashMap;
import java.util.List;

/**
 * Created by mac on 2016/12/15.
 */
public class UserServiceTest extends BaseTest {
    @Autowired
    private UserService userService;

    @Test
    public void getUserInfoTest() {

        List<HashMap<String, String>> userMeta = userService.getUserMeta(1);
        for (HashMap<String, String> map : userMeta) {
            System.out.println(map.toString());
        }

        System.out.println("返回数据长度\t" + userMeta.size());
    }
}
