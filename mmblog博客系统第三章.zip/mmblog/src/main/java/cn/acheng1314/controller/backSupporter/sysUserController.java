package cn.acheng1314.controller.backSupporter;

import cn.acheng1314.domain.ResponseObj;
import cn.acheng1314.domain.User;
import cn.acheng1314.utils.GsonUtils;
import cn.acheng1314.utils.PublicUtil;
import cn.acheng1314.utils.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

/**
 * Created by mac on 2016/12/17.
 */
@Controller
@RequestMapping(value = "/user")
public class sysUserController {
    @RequestMapping(value = "/login")
    public Object userLogin(HttpServletRequest request, String userLogin, String userPass) {
        ResponseObj<User> responseObj = new ResponseObj<>();
        User user;
        if (PublicUtil.isJsonRequest(request)) {    //确认是否是post的json提交
            try {
                user = new GsonUtils().jsonRequest2Bean(request.getInputStream(), User.class);  //转换为指定类型的对象
                userLogin = user.getUserLogin();
                userPass = user.getUserPass();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        if (StringUtils.isEmpty(userLogin) || StringUtils.isEmpty(userPass)) {
            responseObj.setCode(ResponseObj.FAILED);
            responseObj.setMsg(ResponseObj.FAILED_STR);
            return new GsonUtils().toJson(responseObj);
        }

        return null;
    }
}
