package cn.acheng1314.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

/**
 * Created by 程 on 2016/11/25.
 */
@Controller
@RequestMapping("/main")
public class MainController {
    @RequestMapping(value = "/login", method = RequestMethod.GET)
    public String userLogin() {
        return "userLogin";
    }
}
