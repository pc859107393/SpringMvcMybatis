package cn.acheng1314.domain;

import java.util.List;

/**
 * Created by 程 on 2016/12/6.
 */
public class DateCountBean {
    private String date;
    private List<String> idList;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public List<String> getIdList() {
        return idList;
    }

    public void setIdList(List<String> idList) {
        this.idList = idList;
    }
}
