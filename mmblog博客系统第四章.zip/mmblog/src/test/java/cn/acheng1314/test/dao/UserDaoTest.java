package cn.acheng1314.test.dao;

import cn.acheng1314.dao.UserDao;
import cn.acheng1314.domain.User;
import cn.acheng1314.test.BaseTest;
import org.apache.shiro.util.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.HashMap;
import java.util.List;

/**
 * Created by Administrator on 2016/9/25.
 */
public class UserDaoTest extends BaseTest {

    @Autowired
    private UserDao userDao;

    @Test
    public void getUserMetaTest() {
        int userId = 1;
        List<HashMap<String, String>> userMeta = userDao.getUserMeta(userId);
        for (HashMap<String, String> map : userMeta) {
            System.out.println(map.toString());
        }
    }

    @Test
    public void findByIdTest() {
        String userId = "pc859107393";
        User user = userDao.findOneById(userId);
        System.out.println("~~~\n" + user.toString());
        Assert.notNull(user);

    }
}
