package cn.acheng1314.test.dao;

import cn.acheng1314.dao.PostDao;
import cn.acheng1314.domain.PostBean;
import cn.acheng1314.test.BaseTest;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * Created by 程 on 2016/11/27.
 */
public class PostDaoTest extends BaseTest {

    @Autowired
    private PostDao postDao;

    @Test
    public void testPostDao() {
        List<PostBean> list = postDao.findAllPublish(1, 50);
        for (PostBean bean : list) {
            System.out.println("postDaoTest:\n" + bean.toString());
        }
    }

    @Test
    public void testGetPostById() {
        PostBean postBean = postDao.findOneById(300);

        System.out.println("postDaoTest:\n" + postBean.toString());
    }

}
