package cn.acheng1314.test.dao;

import cn.acheng1314.dao.UserDao;
import cn.acheng1314.domain.User;
import cn.acheng1314.test.BaseTest;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Created by Administrator on 2016/9/25.
 */
public class UserDaoTest extends BaseTest {

    @Autowired
    private UserDao userDao;

}
