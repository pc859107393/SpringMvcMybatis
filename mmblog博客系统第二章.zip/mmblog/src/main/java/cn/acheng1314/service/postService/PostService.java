package cn.acheng1314.service.postService;

import cn.acheng1314.domain.DateCountBean;
import cn.acheng1314.domain.PostBean;
import cn.acheng1314.service.BaseService;

import java.util.List;

/**
 * Created by 程 on 2016/11/27.
 */
public interface PostService extends BaseService<PostBean> {
    @Override
    void add(PostBean postBean) throws Exception;

    @Override
    List<PostBean> findAll(int pageNum, int pageSize);

    List<PostBean> findAllPublish(int pageNum, int pageSize);

    /**
     * 获取总条数
     * @return  获取总条数
     */
    int getAllCount();

    /**
     * 获取热点文章
     * @return
     */
    List<PostBean> findAllNew();

    /**
     * 获取所有文章的日期归档
     * @return  返回归档信息
     */
    List<DateCountBean> getAllPostDateCount();
}
