package cn.acheng1314.controller.frontWeb;

import cn.acheng1314.domain.*;
import cn.acheng1314.domain.Response.HomeBean;
import cn.acheng1314.service.postService.PostService;
import cn.acheng1314.utils.GsonUtils;
import cn.acheng1314.utils.PublicUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * Created by 程 on 2016/11/25.
 */
@Controller
@RequestMapping("/front")
public class FrontWebController {

    @Autowired
    private PostService postService;

    @RequestMapping("/main")
    public ModelAndView frontMain() {
        ModelAndView view = new ModelAndView("frontMain");
        view.addObject("homeJson", getHomeJson(null));
        return view;
    }

    @RequestMapping(value = "/findPublishPost"
            , produces = "application/json; charset=utf-8")
    @ResponseBody
    public Object findPublishPost(HttpServletRequest request, int pageNum, int pageSize) throws Exception {
        PageSplit page;
        ResponseList<PostBean> list = new ResponseList<>();

        if (PublicUtil.isJsonRequest(request)) {    //确认是否是post的json提交
            page = new GsonUtils().jsonRequest2Bean(request.getInputStream(), PageSplit.class);  //转换为指定类型的对象
            pageNum = page.getPageNum();
            pageSize = page.getPageSize();
        }
        if (pageNum <= 0) {
            pageNum = 1;
        }
        if (pageSize == 0) {
            pageSize = 10;
        }

        try {
            int toalNum; //总页码
            toalNum = postService.getAllCount();    //先把总条数赋值给总页数，作为缓存变量，减少下面算法的查找次数

            toalNum = toalNum % pageSize > 0 ? toalNum / pageSize + 1 : toalNum / pageSize;     //在每页固定条数下能不能分页完成，有余则加一页码

            List<PostBean> tmp = postService.findAllPublish(pageNum, pageSize);
            if (null == tmp || tmp.size() == 0) {
                list.setCode(ResponseList.EMPUTY);
                list.setMsg(ResponseList.EMPUTY_STR);
                return new GsonUtils().toJson(list);
            }
            list.setCode(ResponseList.OK);
            list.setMsg(ResponseList.OK_STR);
            list.setPageNum(pageNum);
            list.setTotalNum(toalNum);
            list.setPageSize(pageSize);
            list.setData(tmp);
            return new GsonUtils().toJson(list);
        } catch (Exception e) {
            e.printStackTrace();
            //查询失败
            list.setCode(ResponseObj.FAILED);
            list.setMsg(ResponseList.FAILED_STR);
            return new GsonUtils().toJson(list);
        }

    }

    @RequestMapping(value = "/home"
            , produces = "application/json; charset=utf-8")
    @ResponseBody
    public Object getHomeJson(User user) {
        if (null != user) {
            //埋点，AOP日志记录
        }
        HomeBean homeBean = new HomeBean(); //首页内容
        HomeBean.DataBean dataBean = new HomeBean.DataBean();   //首页下面的Data内容对象
        try {
            int toalNum; //总页码

            toalNum = postService.getAllCount();    //先把总条数赋值给总页数，作为缓存变量，减少下面算法的查找次数

            toalNum = toalNum % 10 > 0 ? toalNum / 10 + 1 : toalNum / 10;     //在每页固定条数下能不能分页完成，有余则加一页码

            List<PostBean> postsData = postService.findAllPublish(1, 10);   //首页下面的文章内容
            List<PostBean> newData = postService.findAllNew();   //首页下面的文章内容
            if (null == postsData || postsData.isEmpty()) {
                dataBean.setPosts(null);
            } else {
                dataBean.setPosts(postsData);   //首页文章列表信息设定
            }
            if (null == newData || newData.isEmpty()) {
                dataBean.setNewPosts(null);
            } else {
                dataBean.setNewPosts(newData);   //首页文章列表信息设定
            }
            List<DateCountBean> allPostDateCount = postService.getAllPostDateCount();
            if (null != allPostDateCount && !allPostDateCount.isEmpty()) {
                dataBean.setDate(allPostDateCount);
            } else {
                dataBean.setDate(null);
            }
            dataBean.setPageNum(1);
            dataBean.setPageSize(10);
            dataBean.setTotalNum(toalNum);
            homeBean.setData(dataBean);
            homeBean.setCode(ResponseObj.OK);
            homeBean.setMsg(ResponseList.OK_STR);
            return new GsonUtils().toJson(homeBean);
        } catch (Exception e) {
            e.printStackTrace();
            //查询失败
            homeBean.setCode(ResponseObj.FAILED);
            homeBean.setMsg(ResponseList.FAILED_STR);
            return new GsonUtils().toJson(homeBean);
        }
    }


}
