package cn.acheng1314.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Created by 程 on 2016/11/25.
 */
@Controller
@RequestMapping("/main")
public class MainController {
}
